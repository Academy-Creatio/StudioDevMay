﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $rootnamespace$
{
    class $safeitemname$
    {
        #region Enum
        #endregion

        #region Delegates
        #endregion

        #region Interface
        #endregion

        #region Struct
        #endregion

        #region Class
        #endregion

        #region Constants
        #endregion

        #region Fields
        #endregion

        #region Constructors
        #endregion

        #region Properties
        #endregion

        #region Events
        #endregion

        #region Methods
        #endregion
    }
}
